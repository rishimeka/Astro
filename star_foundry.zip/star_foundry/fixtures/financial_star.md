---
id: astro.research.market.v1
name: Market Research Star
description: Uses base star to compute market insights
content_type: md
tags:
  - research
  - finance
version: v1
created_by: analyst
created_on: 2025-02-01T00:00:00
updated_by: analyst
updated_on: 2025-02-01T00:00:00
references:
  - astro.ic.base.v1
---

Market research prompt that references base star.
