---
id: astro.ic.base.v1
name: Base Star
description: Base star used by others
content_type: md
tags:
  - base
version: v1
created_by: dev
created_on: 2025-01-01T00:00:00
updated_by: dev
updated_on: 2025-01-01T00:00:00
---

This is the base star content.
