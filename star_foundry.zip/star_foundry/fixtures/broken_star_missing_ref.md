---
id: astro.broken.missing.v1
name: Broken Missing Ref
description: References a non-existent star
content_type: md
tags:
  - broken
version: v1
created_by: tester
created_on: 2025-03-01T00:00:00
updated_by: tester
updated_on: 2025-03-01T00:00:00
references:
  - astro.nonexistent.v1
---

This star references a missing id.
