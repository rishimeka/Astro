from __future__ import annotations

from typing import List
from pymongo.collection import Collection
from star_foundry.models import Star
from star_foundry.parsers.markdown_parser import parse_markdown
from star_foundry.parsers.xml_parser import parse_xml
import warnings


class MongoStarLoader:
    def __init__(self, mongo_collection: Collection):
        self.collection = mongo_collection

    def load_all(self) -> List[Star]:
        docs = list(self.collection.find({}))
        stars: list[Star] = []
        for doc in docs:
            # drop mongo's _id if present
            if "_id" in doc:
                doc = {key: value for key, value in doc.items() if key != "_id"}
            try:
                # pydantic v2 model_validate preferred if available
                if hasattr(Star, "model_validate"):
                    star = Star.model_validate(doc)
                else:
                    star = Star(**doc)
                stars.append(star)
            except Exception as e:
                # Attempt to recover when the document contains raw markdown/xml
                # stored as strings instead of fully-structured Star fields.
                try:
                    # common keys: 'raw_markdown', 'markdown', 'content'
                    if isinstance(doc.get("raw_markdown") or doc.get("markdown"), str):
                        raw = doc.get("raw_markdown") or doc.get("markdown")
                        star = parse_markdown(raw)
                        stars.append(star)
                        continue

                    # if content itself looks like markdown frontmatter
                    if isinstance(doc.get("content"), str) and doc.get(
                        "content"
                    ).lstrip().startswith("---"):
                        star = parse_markdown(doc.get("content"))
                        stars.append(star)
                        continue

                    # xml stored in a field named 'xml' or 'content' and starts with '<'
                    if isinstance(doc.get("xml") or doc.get("content"), str):
                        candidate = doc.get("xml") or doc.get("content")
                        if candidate.lstrip().startswith("<"):
                            star = parse_xml(candidate)
                            stars.append(star)
                            continue

                except Exception:
                    # fall through to generic warning below
                    pass

                # Surface validation issues but continue loading others
                warnings.warn(f"Failed validating star document: {e}")
        return stars
