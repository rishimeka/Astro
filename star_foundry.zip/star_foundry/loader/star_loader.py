from typing import List


class StarLoader:
    """Filesystem loading is intentionally disabled.

    Local file storage is not supported in this project. If code attempts
    to instantiate `StarLoader`, it will raise `NotImplementedError`.
    """

    def __init__(self, *args, **kwargs):
        raise NotImplementedError("Local file-based StarLoader is no longer supported.")

    def load_all(self) -> List:  # pragma: no cover - not supported
        raise NotImplementedError("Local file-based StarLoader is no longer supported.")
